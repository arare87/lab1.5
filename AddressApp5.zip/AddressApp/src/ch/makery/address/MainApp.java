package ch.makery.address;
import java.io.IOException;

import javafx.application.Application;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList; 
import ch.makery.address.model.Person;
import ch.makery.address.view.PersonOverviewController;
import java.time.LocalDate;
import ch.makery.address.view.PersonEditDialogController;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
	private ObservableList<Person> personData = FXCollections.observableArrayList();


	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
        this.primaryStage.setTitle("BooksApp");
        initRootLayout();
        showPersonOverview();
	}
	 public Stage getPrimaryStage() {
	        return primaryStage;
	    }

	public MainApp() {
		personData.add(new Person("The Catcher in the Rye ", "Jerome Salinger", "Young adult", "Little, Brown and Company", 4, LocalDate.of(1951, 7, 16)));
	}
	public ObservableList<Person> getPersonData() {
		return personData;
	}
	 public void initRootLayout() {
		    try {
		        // Load the root layout from the fxml file.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
		        rootLayout = (BorderPane) loader.load();

		        // Display the scene containing the root layout.
		        Scene scene = new Scene(rootLayout);
		        primaryStage.setScene(scene);
		        primaryStage.show();
		        
		        // Call showPersonOverview after initializing rootLayout
		        showPersonOverview();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}

		public void showPersonOverview() {
		    try {
		        // Load the person overview.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(MainApp.class.getResource("view/PersonOverview.fxml"));
		        AnchorPane personOverview = (AnchorPane) loader.load();

		        // Set the person overview in the center of the root layout.
		        rootLayout.setCenter(personOverview);

		        // Give the controller access to the main app.
		        PersonOverviewController controller = loader.getController();
		        controller.setMainApp(this);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}
		 public static void main(String[] args) {
		        launch(args);
		    }
		 /**
		  * Открывает диалоговое окно для изменения деталей указанного адресата.
		  * Если пользователь кликнул OK, то изменения сохраняются в предоставленном
		  * объекте адресата и возвращается значение true.
		  * 
		  * @param person - объект адресата, который надо изменить
		  * @return true, если пользователь кликнул OK, в противном случае false.
		  */
		 public boolean showPersonEditDialog(Person person) {
		     try {
		         // Загружаем fxml-файл и создаём новую сцену
		         // для всплывающего диалогового окна.
		         FXMLLoader loader = new FXMLLoader();
		         loader.setLocation(MainApp.class.getResource("view/PersonEditDialog.fxml"));
		         AnchorPane page = (AnchorPane) loader.load();

		         // Создаём диалоговое окно Stage.
		         Stage dialogStage = new Stage();
		         dialogStage.setTitle("Edit Book");
		         dialogStage.initModality(Modality.WINDOW_MODAL);
		         dialogStage.initOwner(primaryStage);
		         Scene scene = new Scene(page);
		         dialogStage.setScene(scene);

		         // Передаём адресата в контроллер.
		         PersonEditDialogController controller = loader.getController();
		         controller.setDialogStage(dialogStage);
		         controller.setPerson(person);

		         // Отображаем диалоговое окно и ждём, пока пользователь его не закроет
		         dialogStage.showAndWait();

		         return controller.isOkClicked();
		     } catch (IOException e) {
		         e.printStackTrace();
		         return false;
		     }
		 }
}
